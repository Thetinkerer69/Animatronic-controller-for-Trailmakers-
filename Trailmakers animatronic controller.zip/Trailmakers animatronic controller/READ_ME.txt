README: Trailmakers Animatronic Controller
Application Name: Trailmakers Animatronic Controller
Version: 1.0
Author:

📝 Purpose
This application allows you to record and play back keyboard choreography to make complex animatronics in the game Trailmakers. It synchronizes your key presses with a music track, so you can easily create and replay intricate sequences.

🚀 How to Use
Install: Run the setup.exe to install the application.

Open Trailmakers: Launch the Trailmakers game and load your animatronic build.

Start the Controller: Open the Animatronic Music Controller application from your desktop or Start Menu.

Select a Song:

The application will automatically find songs that are installed with it. Select a song from the dropdown menu.

Record Choreography:

Click the "Record Choreography" button.

The application will start recording in 5 seconds. This gives you time to click on the Trailmakers game window to make it the active application.

As the music plays, press and hold the keys you want to record. When you release a key, the application records its duration.

To stop recording, press the Esc key or wait for the song to finish. Your choreography will be saved to a .json file.

Play Choreography:

Select a song and the choreography file you wish to play.

Click the "Play Choreography" button.

The application will start playback in 5 seconds. Again, this gives you time to click on the Trailmakers game window.

The application will automatically press and release the recorded keys for you.

Stop:

You can press the Stop button at any time to immediately end recording or playback.

⚙️ Key Controls
Keyboard Keys: Any key you press on your keyboard will be recorded.

Stop Recording/Playback: Press the Esc key on your keyboard.

⚠️ Important Notes
Game Focus: The application sends key presses to the currently active window. You must click on the Trailmakers game window after starting a recording or playback for the controls to work.

Latency Offset: You can adjust the "Global Latency Offset (ms)" to fine-tune the timing of your key presses relative to the music. A negative number makes the presses happen earlier; a positive number makes them happen later.

📁 Adding More Songs
To add new songs, open the folder where you installed the application (e.g., C:\Program Files\Trailmakers Animatronic Controller).

Inside, you will find a songs folder.

For each new song, create a new subfolder with the song's name (e.g., songs/New Song Title).

Place the MP3 file inside that folder, making sure it has the same name as the folder (e.g., New Song Title.mp3).

❓ Troubleshooting
If the application doesn't seem to press keys in the game, make sure the Trailmakers game window is the active window.

If the music and key presses are not synchronized correctly, adjust the "Latency Offset."

🙏 Credits
Created by: [Your Name]

Special thanks to: [Any friends or resources that helped]